# MovieApp

## To Do:
- [ ] - Add Home Button
