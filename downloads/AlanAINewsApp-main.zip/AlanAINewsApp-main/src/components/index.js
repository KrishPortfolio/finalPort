export { default as Modal } from './Modal/Modal';
export { default as NewsCards } from './NewsCards/NewsCards';
