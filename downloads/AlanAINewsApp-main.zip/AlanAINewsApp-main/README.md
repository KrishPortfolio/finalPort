# Voice Controlled React News Application - Alan AI Voice Assistant
 
## Setup:
- download repository
- run ```npm i && npm start``` to start development server
